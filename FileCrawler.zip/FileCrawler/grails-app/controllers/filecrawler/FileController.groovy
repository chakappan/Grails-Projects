package filecrawler

import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class FileController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond File.list(params), model:[fileCount: File.count()]
    }

    def show(File file) {
        respond file
    }

    def create() {
        respond new File(params)
    }

    @Transactional
    def save(File file) {
        if (file == null) {
            transactionStatus.setRollbackOnly()
            notFound()
            return
        }

        if (file.hasErrors()) {
            transactionStatus.setRollbackOnly()
            respond file.errors, view:'create'
            return
        }

        file.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'file.label', default: 'File'), file.id])
                redirect file
            }
            '*' { respond file, [status: CREATED] }
        }
    }

    def edit(File file) {
        respond file
    }

    @Transactional
    def update(File file) {
        if (file == null) {
            transactionStatus.setRollbackOnly()
            notFound()
            return
        }

        if (file.hasErrors()) {
            transactionStatus.setRollbackOnly()
            respond file.errors, view:'edit'
            return
        }

        file.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'file.label', default: 'File'), file.id])
                redirect file
            }
            '*'{ respond file, [status: OK] }
        }
    }

    @Transactional
    def delete(File file) {

        if (file == null) {
            transactionStatus.setRollbackOnly()
            notFound()
            return
        }

        file.delete flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'file.label', default: 'File'), file.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'file.label', default: 'File'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
