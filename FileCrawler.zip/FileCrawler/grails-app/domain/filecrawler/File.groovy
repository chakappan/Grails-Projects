package filecrawler

class File {

    static constraints = {
    }
}
