package filecrawler

class Folder {
 def path
 def count
     static hasMany = [files:File]
}
