This folder contains some standard DSL descriptor files that are specific to this version
 of Groovy-Eclipse and are applicable for all projects in your workspace.  In general, 
 you should not edit the files here.  If you want to add custom DSLDs for the entire
 workspace, then you should place them in ~/.groovy/greclipse/dsld. 